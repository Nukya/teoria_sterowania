% Placeholder content for zadanie 4
