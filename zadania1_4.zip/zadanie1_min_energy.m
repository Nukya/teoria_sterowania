% Placeholder content for zadanie 1
