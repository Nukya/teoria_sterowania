% Placeholder content for zadanie 2
