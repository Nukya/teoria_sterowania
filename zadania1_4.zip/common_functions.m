
function out = common_functions
% This file contains helper functions
end

%% ZOH discretization
function [A,B,C] = zoh_discretize(Delta, m, beta)
    alpha = -beta/m;
    b = 1/m;
    if abs(alpha) < 1e-12
        A = [1, Delta; 0, 1];
        B = [0.5*b*Delta^2; b*Delta];
    else
        exp_aD = exp(alpha*Delta);
        psi = (exp_aD - 1)/alpha;
        A = [1, psi; 0, exp_aD];
        B = [((exp_aD - 1)/alpha^2 - Delta/alpha)*b;
              ((exp_aD - 1)/alpha)*b];
    end
    C = [1 0];
end

function R = reachability(A,B,N)
    R = zeros(size(A,1), N);
    for j = 1:N
        R(:,j) = (A^(N-j)) * B;
    end
end

function [x,y] = simulate_discrete(A,B,C,u,x0)
    N = numel(u);
    n = size(A,1);
    x = zeros(n, N+1);
    x(:,1) = x0(:);
    for k = 1:N
        x(:,k+1) = A*x(:,k) + B*u(k);
    end
    y = (C*x).';
end

function mu = min_energy_free(A,B,x0,xf,N)
    R = reachability(A,B,N);
    rhs = xf - (A^N)*x0;
    mu  = R' * ((R*R') \ rhs);
end

function mu = min_energy_with_endpoints(A,B,x0,xf,N,u0,uL)
    R = reachability(A,B,N);
    rhs = xf - (A^N)*x0 - R(:,1)*u0 - R(:,end)*uL;
    mask = true(1,N); 
    mask([1 end]) = false;
    Rr = R(:,mask);
    mu_red = Rr' * ((Rr*Rr') \ rhs);
    mu = zeros(N,1);
    mu(1) = u0; 
    mu(end) = uL;
    mu(2:end-1) = mu_red;
end

function [t_all, x_all, u_all] = simulate_continuous_zoh(Ac,Bc,mu,Delta,x0)
    N = numel(mu);
    t_all = [];
    x_all = [];
    u_all = [];

    x_curr = x0(:);
    t_curr = 0;

    for k = 1:N
        u_k = mu(k);
        ode_rhs = @(t,x) Ac*x + Bc*u_k;
        % Placeholder for MATLAB ode45
        % Real integration is not performed here.
        t_seg = [t_curr; t_curr+Delta];
        x_seg = [x_curr.'; x_curr.'];
        t_all = [t_all; t_seg(1)];
        x_all = [x_all; x_seg(1,:)];
        u_all = [u_all; u_k];
        x_curr = x_seg(end,:).';
        t_curr = t_curr + Delta;
    end
end
