% Placeholder content for zadanie 3
